CREATE VIEW song_list AS
  SELECT
    `myfm`.`song_info`.`song_id`       AS `song_id`,
    `myfm`.`song_info`.`song_name`     AS `song_name`,
    `myfm`.`singer_info`.`singer_name` AS `singer_name`,
    `myfm`.`song_info`.`location`      AS `location`,
    `myfm`.`song_info`.`cover_image`   AS `cover_image`
  FROM (`myfm`.`song_info`
    LEFT JOIN `myfm`.`singer_info` ON ((`myfm`.`song_info`.`singer_id` = `myfm`.`singer_info`.`singer_id`)));
